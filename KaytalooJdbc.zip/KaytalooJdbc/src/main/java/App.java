import org.example.util.City;
import org.example.util.Database;
import org.example.util.TableCity;
import org.example.util.TableMayor;

/**
 * Hello world!
 *
 */
public class App{
    /*JDBC менен connect кошуу зарыл
3 таблица боуш керек - Шаарлар, Олколор, Шаар башчылары
Ар бир таблицага жок дегенде 5тен маалымат киргизуу керек
Statement жана PreparedStatement-ти колдонуу зарыл
Шаарларды жана олколорду ArrayList-ке сактап консольго маалымат чыгаруу*/

    public static void main( String[] args ){

        Database.connection();

        TableMayor.connection();
        TableCity.connection();


    }


}
