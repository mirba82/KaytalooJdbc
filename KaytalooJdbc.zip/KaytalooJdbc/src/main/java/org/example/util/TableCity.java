package org.example.util;

import java.sql.*;

public class TableCity {
    private static final String url = "jdbc:postgresql://localhost:5432/postgres";
    private static final String user = "postgres";
    private static final String password = "mirba85";

    public static Connection connection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            Statement smt = conn.createStatement();
            String SQL = "CREATE TABLE city"+
                        "(id SERIAL PRIMARY KEY,"+
                        "city_name VARCHAR(250),"+
                        "mayor_id INT REFERENCES mayor(id))";

            smt.executeUpdate(SQL);
            System.out.println("Created table successfully");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
//    public void addUsers(String name){
//        try(Connection conn =connection()){
//            PreparedStatement stm = conn.prepareStatement(
//                    "INSERT INTO city(name )VALUES (?);");
//            stm.setString(1,name);
//    }catch (SQLException e){
//        System.out.println(e.getMessage());
//        }
//
}
