package org.example.util;

public class City {
    private int id;
    private String city_name;
    private int mayorId;

    public City(int id, String city_name, int mayorId) {
        this.id = id;
        this.city_name = city_name;
        this.mayorId = mayorId;
    }

    public int getId() {
        return id;
    }

    public void setCityId(int id) {
        this.id = id;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public int getMayorId() {
        return mayorId;
    }

    public void setMayorId(int mayorId) {
        this.mayorId = mayorId;
    }

    @Override
    public String toString() {
        return "City{" +
                "cityId=" + id +
                ", city_name='" + city_name + '\'' +
                ", mayorId=" + mayorId +
                '}';
    }
}
