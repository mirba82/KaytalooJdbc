package org.example.util;

public class Country {
    private int id;
    private String countryName;
    private int population;
    private int cityId;
}
