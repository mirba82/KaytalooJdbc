package org.example.util;

public class Mayor {
    private int id;
    private String mayorName;
    private int cityId;

    public Mayor(int id, String mayor_name, int cityId) {
        this.cityId = cityId;
        this.mayorName = mayor_name;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMayorName() {
        return mayorName;
    }

    public void setMayorName(String mayorName) {
        this.mayorName = mayorName;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    @Override
    public String toString() {
        return "Mayor{" +
                "id=" + id +
                ", mayorName='" + mayorName + '\'' +
                ", cityId=" + cityId +
                '}';
    }
}

